#ifndef __SOURCE_H
#define __SOURCE_H

// #include "User.h"
#include "System.h"
#include <iostream>
using namespace std;

const unsigned int MAX_OPTION = 11;
const unsigned int EXIT_OPTION = 11;
const int NOT_FOUND = -1;

void runMenu(System& system);
void addBuyer(System& system);
void addVendor(System& system);
void addItemToVendor(System& system);
void addFeedbackToVendor();
void addProductToCartOfBuyer();
void performOrderForBuyer();
void orderPaymentForBuyer();
void showAllBuyers();
void showAllVendors();
void showSpecificProduct();


// Vendor* findVendor();	???

#endif
