#ifndef __BUYER_H
#define __BUYER_H

class Product;
class Order;

class Buyer
{
public:
	void purchase();
	// add to cart?
	// remove from cart?

private:
	const Product**		m_cart;	//	this is an array of products that the buyer considers purchasing. Dynamically allocated
	/*
	we're trying to create an array of pointers to const products,
	meaning the buyer has a pointer to a product, but he cannot change the product itself
	note that once we perform the purchase, the buyer has his own version of that product
	*/
	
	int					m_phySize, m_logSize;		//	variables to manage the dynamic cart array
	Order*				m_purchaseHistory;	//	an array of past purchases
	// Product* ownedProducts;	//	??? do we need this?
};

#endif 