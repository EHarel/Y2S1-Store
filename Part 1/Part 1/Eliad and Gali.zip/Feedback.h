#ifndef __FEEDBACK_H
#define __FEEDBACK_H

const int FEED_LEN = 150;

//class Date;
#include "Date.h"
class Buyer;

class Feedback
{
public:
	// GETTERS AND SETTERS
private:
	Date				m_date;
	const Buyer*		m_feedbackGiver; // information about feedback provider - is it just a pointer to the customer, or the customer's details copied here?
	char				appraisal[FEED_LEN];
};
#endif 