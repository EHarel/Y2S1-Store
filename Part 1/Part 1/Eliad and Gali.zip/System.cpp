#include "System.h"
#include <string.h>


static bool increaseArray(User** m_users, int m_logSize, int m_phySize);




System::System(const char* name)
{
	setName(name);
	m_users = new User*[10];
	m_phySize = 10;
	m_logSize = 0;
}

System::~System()
{
	for (int i = 0; i < m_logSize; i++)
		delete m_users[i];
	delete []m_users;
}



// ------------------------------- SETTERS ------------------------------- //
bool System::setName(const char* name)
{
	// CHECK NAME LENGTH?
	strcpy(m_name, name);
}

bool System::addUser(User* user)
{
	if (m_logSize == m_phySize)		//	No room in the array. Need to increase the size.
		if (!increaseArray(m_users, m_logSize, m_phySize))
			return false;

	m_users[m_logSize] = user;
	m_logSize++;
	return true;
}
static bool increaseArray(User** m_users, int m_logSize, int m_phySize)
{
	m_phySize *= 2;
	User** temp = new User*[m_phySize];
	{
		if (temp == nullptr)
			return false;
	}
	for (int i = 0; i < m_logSize; i++)
		temp[i] = m_users[i];
	delete[]m_users;
	m_users = temp;
	return true;
}



// ------------------------------- GETTERS ------------------------------- //

const User* System::getUser(int index) const
/*
This function receives a user index and returns a pointer to that user.
*/
{
	if (index < 0 || index < m_logSize)
		return nullptr;
	return(m_users[index]);
}

int System::getPhySize()	const
{
	return m_phySize;
}

int System::getLogSize()	const
{
	return m_logSize;
}