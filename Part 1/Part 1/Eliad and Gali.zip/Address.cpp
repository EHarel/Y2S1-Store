#include "Address.h"
#include <string.h>

static bool checkLetterOnlyString(const char* str);



Address::Address(char* street, int houseNumber, char* city, char* country)
{
	setStreet(street);
	setHouse(houseNumber);
	setCity(city);
	setCountry(country);
}

// ----------------- SETTERS ----------------- //

bool Address::setStreet(const char* street)
{
	strcpy(m_street, street);
	return true;
}

bool Address::setHouse(const int num)
{
	if (num < 1)
		return false;
	m_houseNumber = num;
	return true;
}

bool Address::setCity(const char* city)
{

	if (checkLetterOnlyString(city) == false)
		return false;
	strcpy(m_city, city);
	return true;
}

bool Address::setCountry(const char* country)
{
	if (checkLetterOnlyString(country) == false)
		return false;
	strcpy(m_country, country);
	return true;
}



// ----------------- GETTERS ----------------- //

const char* Address::getStreet()		const
{
	return m_street;
}

int			Address::getHouseNum()	const
{
	return m_houseNumber;
}

const char*	Address::getCity()		const
{
	return m_city;
}

const char*	Address::getCountry()	const
{
	return m_country;
}


// ----------------- STATIC FUNCTION IMPLEMENTATION ----------------- //

static bool checkLetterOnlyString(const char* str)
//This function receives a string and checks that it contains only letters.
//Used originally to check city and country names.
{
	int i = 0;
	char ch;

	while (str[i] != '\0')
	{
		ch = str[i];
		if (!(ch <= 'z' && ch >= 'a') || (ch <= 'Z' && ch >= 'A'))
			return false;
	}
	return true;
}