
#include "Vendor.h"

#include <iostream>
using namespace std;

Vendor::Vendor()
{
	m_feedPhySize = 10;
	m_feedLogSize = 0;
	m_feedbacks = new Feedback*[m_feedPhySize];
	if (!m_feedbacks)
		cout << "Error: Failed to allocate space for feedbacks for Vendor.\n";

	m_merchPhySize = 10;
	m_merchLogSize = 0;
	m_merchandise = new Product*[m_merchPhySize];
	if (!m_merchandise)
		cout << "Error: Failed to allocate space for merchandise for Vendor.\n";
}//constructor

Vendor::~Vendor()
{
	for (int i = 0; i < m_feedLogSize; i++)
		delete m_feedbacks[i];
	delete[]m_feedbacks;

	for (i = 0; i < m_merchLogSize; i++)
		delete m_merchandise[i];
	delete[]m_merchandise;
}

bool addFeedback(Feedback* newFeed)
{
	if()
}

bool addProduct(Product* newProd)
{
	
}