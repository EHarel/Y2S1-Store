#ifndef __ADDRESS_H
#define __ADDRESS_H

// #include <iostream>

int const LEN = 31;

class Address 
{
public:
	Address(char* street, int houseNumber, char* city, char* country);

	bool setStreet(const char* street);
	bool setHouse(const int num);
	bool setCity(const char* city);
	bool setCountry(const char* country);

	const char* getStreet()		const;
	int			getHouseNum()	const;
	const char*	getCity()		const;
	const char*	getCountry()	const;

	//	DESTRUCTOR
private:
	char		m_street[LEN];
	int			m_houseNumber;
	char		m_city[LEN];
	char		m_country[LEN];
};
#endif