#include "Source.h"
#include "Address.h"
#include "Buyer.h"
#include "Vendor.h"

// -----------------------	STATIC FUNCTION DECLARATIONS ----------------------- //
static void printOptions();
static Address* createAddress();
static Buyer* createBuyer();
static Vendor* createVendor();

static int searchUsername(System& system, char* name);
static bool allocationCheck(void* ptr);




void runMenu(System& system)
//This function runs the menu of the program.
//It continues until the user decides to stop.
{
	bool fContinue = true;
	unsigned short int optionAnswer;
	while (fContinue)
	{
		cout << "Choose an option:\n"; 
		printOptions();
		cin >> optionAnswer;
		while (optionAnswer < 1 || optionAnswer > MAX_OPTION)
		{
			cout << "Please enter a number within the range (1-" << MAX_OPTION << "): ";
			cin >> optionAnswer;
		}
		switch (optionAnswer)
		{
		case 1:	
			addBuyer(system);
			break;
		case 2:	
			addVendor(system);
			break;
		case 3:		//	add item to vendor
			addItemToVendor(system);
			break;
		case 4:		//	add feedback to vendor; we check that feedback giver actually purchased from vendor
			addFeedbackToVendor();
			break;
		case 5:		//	add product to cart of buyer
			addProductToCartOfBuyer();
			break;
		case 6:		//	perform order for buyer
			performOrderForBuyer();
			break;
		case 7:		//	order payment for buyer
			orderPaymentForBuyer();
			break;
		case 8:		//	show all buyer details
			showAllBuyers();
			break;
		case 9:		//	show all vendor details
			showAllVendors();
			break;
		case 10:	//	show details of all products of certain name
			showSpecificProduct();
			break;
		case 11:	//	exit
			fContinue = false;
			break;
		}
	}//while
	cout << endl;
}//addOrRemoveSurvivors

static void printOptions()
// This function prints all the options in the menu.
{
	cout << "\t1) Add buyer\n";
	cout << "\t2) Add vendor\n";
	cout << "\t3) Add item to vendor\n";
	cout << "\t4) Add feedback to vendor\n";
	cout << "\t5) Add product to cart of buyer\n";
	cout << "\t6) Make purchase for buyer\n";
	cout << "\t7) Order payment for buyer\n";
	cout << "\t8) Show details of all buyers\n";
	cout << "\t9) Show details of all vendors\n";
	cout << "\t10) Show details of all products of certain name\n";
	cout << "\t11) Exit\n";
}



void addBuyer(System& system)
{
	char name[LEN];
	bool newUsername = receiveNewUsername(name, system);	//	This function returns true if the chosen name does not exist in the system.
	if (!newUsername)	// Chosen name does exist.
		return;

	// At this point, we've established the entered name is new. Now we collect the rest of the data to create a user.
	int password;
	cout << "Please enter a password (numbers only): ";
	cin >> password;
	Address* address = createAddress();
	Vendor* vendor = nullptr;
	Buyer* buyer = createBuyer();
	User* newUser = new User(name, password, address, vendor, buyer);
	system.addUser(newUser);
}


void addVendor(System& system)
{
	char name[LEN];
	bool newUsername = receiveNewUsername(name, system);	//	This function returns true if the chosen name does not exist in the system.
	if (!newUsername)	// Chosen name does exist.
		return;

	// At this point, we've established the entered name is new. Now we collect the rest of the data to create a user.
	int password;
	cout << "Please enter a password (numbers only): ";
	cin >> password;
	Address* address = createAddress();
	Vendor* vendor = createVendor();
	Buyer* buyer = nullptr;
	User* newUser = new User(name, password, address, vendor, buyer);
	system.addUser(newUser);
}

bool receiveNewUsername(char* name, System& system)
/*
This function receives a new username, and checks if it exists in the system.
If it does, it asks the user if it wishes to try a different name.
If he rejects, the loop ends.
*/
{
	bool uContinue=true;		//	user continue
	while (uContinue)
	{
		cout << "Please enter a new username, up to " << LEN - 1 << " letters: ";
		cin >> name;

		if (searchUsername(system, name) != NOT_FOUND)	//	Found an existing username of that name.
		{
			cout << "That username exists already. Would you like to try a new username? (y\\n)\n ";
			char ch;
			cin >> ch;
			getchar();
			while (ch != 'n' && ch != 'y')
			{
				cout << "Please enter a valid option (y\\n)\n";
				cin >> ch;
				getchar();
			}
			if (ch == 'n')			//	User wishes to stop and not try a new username.
				return false;
		}
		else
			uContinue = false;
	}//while
	return true;
}


void addItemToVendor(System& system)
{
	char name[LEN];
	cout << "Please enter the username of the vendor you would like to add an item to: ";
	cin >> name;

	int index = searchUsername(system, name);
	if (index = NOT_FOUND)
	{
		cout << "No such username exists.\n";
		return;						//	or maybe do another "do you want to continue?" loop?
	}

	//	IDEA: what about two arrays - one of buyers one of sellers
	//	if name exists:
	//			enter product name (not yet "new" product)
	//			search for product (does he alreadfy have one like this?)
	//			if no such item exists = createProduct
	//			method: insert product
}

void addFeedbackToVendor()
{
	
	//1)	receive vendor name and search for him
	//	save a pointer to a vendor (does the function return a pointer?)
	//2) regular if\else (if not found name...)
	//3) found name:
	//	4) createFeedback?
	//	5) add feedback to array of feedbacks of vendor

	
}

void addProductToCartOfBuyer()
{
	/*
	search product name across ALL VENDORS
		save all vendors who have this product
		display all vendor options to choose + their price
		go to the vendor and "take" the product chosen
			copy address of product in vendor's merchandise 
	*/
}

void performOrderForBuyer()	// purchase?
{
	// 
}

void orderPaymentForBuyer()
{

}

void showAllBuyers()
{
	// go over array of buyers
}

void showAllVendors()
{
	// go over array of vendors
}

void showSpecificProduct()
{
	// productWeb?
}






// ------------------------------- STATIC FUNCTIONS------------------------------- //

static int searchUsername(System& system, char* name)
/*
This function receives a name, and searches the system's userbase for that name.
It returns true if that name was found, as well as that user's index.
False otherwise.

Note: we can also have it return only an int (only the index), 
with -1 indicating no such user was found, 
and any positive number being the index.
*/
{
	int size = system.getLogSize;
	for (int i = 0; i < size; i++)
	{
		const User* user = system.getUser(i);
		if (strcmp(name, user->getName) == 0)		//	found the name
			return i;
	}
	return NOT_FOUND;
}

static Address* createAddress()
{
	char		street[LEN];
	int			houseNumber;
	char		city[LEN];
	char		country[LEN];

	cout << "Please enter the following details for a new address.\n";
	cout << "Street: ";
	cin >> street;
	cout << "House number: ";
	cin >> houseNumber;
	cout << "City: ";
	cin >> city;
	cout << "Country: ";
	cin >> country;

	Address* address = new Address(street, houseNumber, city, country);
	if (!allocationCheck(address))
		cout << "Failed to allocate space for address.\n";
	return address;
}

static Buyer* createBuyer()
{
	Buyer* newBuyer = new Buyer();
	if (!allocationCheck(newBuyer))
		cout << "Allocation error in creating a new buyer.\n";
	return newBuyer;
}

static Vendor* createVendor()
{
	Vendor* newVendor = new Vendor();
	if (!allocationCheck(newVendor))
		cout << "Allocation error in creating a new buyer.\n";
	return newVendor;
}



static bool allocationCheck(void* ptr)
{
	if (!ptr)
		return false;
	return true;
}