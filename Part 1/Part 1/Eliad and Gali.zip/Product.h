#ifndef __PROD_H
#define __PROD_H

#include <iostream>
using namespace std;

const int LEN = 20;

class Product
{
public:
	const char* eCategoryNames[4] = { "Children", "Electricity", "Office", "Clothing" };
	enum eCategory { CHILDREN, ELECTRICITY, OFFICE, CLOTHING };
	Product(char* name, double price, int serial, eCategory category);	//	constructor; receives initial values

	const char* getName()			const;
	double getPrice()				const;
	int getSerial()					const;
	eCategory getCategory()			const;

	void setName(const char* name);
	void setPrice(const double price);
	void setSerial(int serial);
	void setCategory(eCategory category);

private:
	char		m_name[LEN];
	double		m_price;
	int			m_serial;
	eCategory	m_category;
};

#endif