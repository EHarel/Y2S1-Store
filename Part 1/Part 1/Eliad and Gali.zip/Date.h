#ifndef __DATE_H
#define __DATE_H

class Date
{
public:
	Date(unsigned int day, unsigned int month, unsigned int year);

	void setDay(unsigned int day);
	void setMonth(unsigned int month);
	void setYear(unsigned int year);
private:
	unsigned int	m_day;
	unsigned int	m_month;
	unsigned int	m_year;
};
#endif