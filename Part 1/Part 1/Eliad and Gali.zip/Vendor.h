#ifndef __VENDOR_H
#define __VENDOR_H

class Feedback;
class Product;

class Vendor
{
public:
	Vendor();

	bool addFeedback(Feedback* newFeed);
	bool addProduct(Product* newProd);

	~Vendor();
private:
	Feedback**		m_feedbacks;						//	dynamically allocated array of feedbacks received
	int				m_feedPhySize, m_feedLogSize;		//	sizes for the feedback array
	Product**		m_merchandise;						//	dynamically allocated array of products
	int				m_merchPhySize, m_merchLogSize;
};
#endif