#ifndef __ORDER_H
#define __ORDER_H

// #include "Buyer.h"
class Product;
class Vendor;
class Buyer;

class Order
{
public:
	// SETTERS BUYERS CONSTRUCTOR
private:
	const Product*				m_products;
	double						m_totalCost;		// const? will this reasonably change?
	const Vendor*				m_vendor;
	const Buyer*				m_buyer;
};

#endif 