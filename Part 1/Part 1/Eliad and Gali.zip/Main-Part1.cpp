#include "Source.h"

void main()
{
	char name[LEN];
	cout << "Enter the name of the system: ";
	cin >> name;

	System system(name);
	runMenu(system);
}

/*
How about two arrays - one for Buyers, one for Vendors

SERIAL NUMBER: how to do it? just a global number to advance?
FOr each category of items - a number that starts differently
e.g.
electric - 10000000
children - 20000000
...

IDEA: findVendor function? seems to be a recurring use (e.g. searching for vendor name)

QUESTION: is there a limit on the amount of feedback a buyer can give a seller?

IDEA: ProductWeb - an array of all products in the system
		array of vendors
		array of index for the vendors (where the product is located in each vendor)

To do:
	In system add array of products, vendors and sellers

*/

