#include "User.h"
#include "Address.h"
#include "Vendor.h"
#include "Buyer.h"
#include <string.h>


User::User(char* name, int password, Address* address, Vendor* vendor, Buyer* buyer)
{
	setUserName(name);
	setPassword(password);
	setAddress(address);

	if (vendor = nullptr)
	{
		m_vendorJob = nullptr;
		m_buyer = buyer;
	}
	else
	{
		m_vendorJob = vendor;
		m_buyer = nullptr;
	}
}


// ----------------- SETTERS ----------------- //

bool User::setUserName(const char* name)
{
	strcpy(m_userName, name);
	return true;
}

bool User::setPassword(const int password)
{
	if (password < 0)
		return false;	//	cannot enter a negative number
	m_password = password;
}

bool User::setAddress(Address* address)
//	We'll use pointers here just for ease of reading.
//	We could use a single char* for all the names, to spare variables, 
//	but it's a minor cost for readability
{
	m_address = address;



	//const char* street = address.getStreet();
	//if (m_address.setStreet(street)==false)
	//	return false;

	//int num = address.getHouseNum();
	//if (m_address.setHouse(num) == false)
	//	return false;

	//const char* city = address.getCity();
	//if (m_address.setCity(city) == false)
	//	return false;

	//const char* country = address.getCountry();
	//if (m_address.setCountry(country) == false)
	//	return false;

	//return true;
}

bool User::setStatus(eStatus status)
{
	if (status > 1 || status < 0)
		return false;
	m_status = status;
	return true;
}



// ----------------- GETTERS ----------------- //

const char* User::getName() const
{
	return m_userName;
}

int User::getPassword() const //	Do we actually need this available?
{
	return m_password;
}
const Address& User::getAddress() const
{
	return m_address;
}

User::eStatus User::getStatus()	const
{
	return m_status;
}