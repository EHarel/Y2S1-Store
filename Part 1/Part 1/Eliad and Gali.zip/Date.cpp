#include "Date.h"


Date::Date(unsigned int day, unsigned int month, unsigned int year)
{
	setDay(day);
	setMonth(month);
	setYear(year);
}

void Date::setDay(unsigned int day)
{
	// CHECKS! VALIDITY CHECKS. DAY NOT BEYOND 31
}

void Date::setMonth(unsigned int month)
{
	// CHECKS!
}

void Date::setYear(unsigned int year)
{
	// CHECKS!
}