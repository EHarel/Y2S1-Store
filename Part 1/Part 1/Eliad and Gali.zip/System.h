#ifndef __SYSTEM_H
#define __SYSTEM_H

#include "User.h"

class System
{
public:
	System(const char* name);
	
	//	findVendor method?

	bool setName(const char* name);
	bool addUser(User* user);

	const User* getUser(int index) const;

	int getPhySize()	const;
	int getLogSize()	const;

	~System();
private:
	char			m_name[LEN];		// name of the system
	User**			m_users;			//	Dynamically allocated array of user pointers. Elements being pointers makes it easier to realloc - we just copy pointers instead of whole classes
	int				m_phySize, m_logSize;

	// class BuyersArr
	// class VendorsArr
	// class ProductsArr
	// buyers and vendors array?
	// products array
};
#endif 