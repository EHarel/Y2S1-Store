#include "Product.h"

Product::Product(char* name, double price, int serial, eCategory category)
// Constructor - receives the starting values
{

}//Product constructor


 // ----------------- GETTERS ----------------- //
const char* Product::getName() const
{

}
double Product::getPrice() const
{

}

int Product::getSerial() const
{

}

Product::eCategory Product::getCategory() const
{

}



// ----------------- SETTTERS ----------------- //
void Product::setName(const char* name)
{

}

void Product::setPrice(const double price)
{

}

void Product::setSerial(int serial)
{

}

void Product::setCategory(Product::eCategory category)
{

}