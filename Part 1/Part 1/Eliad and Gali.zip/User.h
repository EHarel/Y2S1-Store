#ifndef __USER_H
#define __USER_H

//#include "Vendor.h"
//#include "Buyer.h"
// #include <iostream>
// using namespace std;

class Vendor;
class Buyer;
class Address;

int const LEN = 31;

class User
{
public:
	enum eStatus { BUYER, VENDOR };
	User(char* name, int password, Address* address, Vendor* vendor, Buyer* buyer);

	bool setUserName(const char* name);
	bool setPassword(const int password);
	bool setAddress(Address* address);
	bool setStatus(eStatus status);

	const char*		getName()		const;
	int				getPassword()	const;	//	Do we actually need this available?
	const Address&	getAddress()	const;
	eStatus			getStatus()		const;

private:
	char				m_userName[LEN];
	int					m_password;
	Address*			m_address;
	eStatus				m_status;	//	a user can either buy or sell, but not be both
	Vendor*				m_vendorJob;
	Buyer*				m_buyer;		//	EW CHANGE THIS


	// How to connect a user to his side-gig as a vendor or buyer?
	// A pointer to each of those objects? With the "forbidden" one being null?
}
#endif // !__USER_H
